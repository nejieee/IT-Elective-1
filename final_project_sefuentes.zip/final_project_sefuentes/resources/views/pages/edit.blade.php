@extends('layout.master')
@section('title')
  Edit Event
@endsection
@section('content')

<div class="container pt-4">
  <div class="col-md-8 offset-md-2">

      <form action="{{route('update',$event->id)}}" method="post">
        @csrf
        @method('post')
        <div class = "container">
          <div class = "row">
            <div class="form-group">
              <div class="col-md-6 form">
            <center>    <h4> Edit Event </h4> </center>
            <label class="form-label"> New task</label>
            <input type="text" class="form-control" name="event_name" required placeholder="Enter Event here" value="{{ $event->event_name}}" >
            <label class="form-label"> Schedule</label>
            <input type="date" class="form-control" name="date" value="{{ $event->date}}">
            <label class="form-label"> Venue </label>
            <input type="text" class="form-control" name="venue"required placeholder="Enter Venue here" value="{{ $event->venue}}">
            <label class="form-label"> In charge </label>
            <input type="text" class="form-control" name="incharge"required placeholder="Enter In charge's name here" value="{{ $event->incharge}}">
            <center><input type="submit" value="Add" class="mt-2 btn btn-success">
            <a href="{{route('front-page')}}" class="mt-2 btn btn-danger"> Cancel </a> </center>
              </div>
            </div>
          </div>
        </div>

      </form>
    </div>
</div>
@endsection

@extends('layout.master')
@section('title')
  Event Management System
@endsection
@section('content')
<div class = "container border border-dark mt-3 pt-3"> <br>
  <h2> <center> Event Management System </center></h2> <br>
      <div class="add">
      <a href="{{route('add')}}"> <i class="fa fa-plus-circle fa-3x" aria-hidden="true" ></i> </a><br> 
    </div>
<div class="row-grid">

      @foreach($events as $event)
            <div>
              <div class = "container"> <br>
                <h4>{{$event->event_name}} </h4>
                    <a href="{{route('view', $event->id)}}"><i class="fa fa-eye" style="font-size:36px; color:black"></i></a>
                    <a href="{{route('edit', $event->id)}}"><i class="fa fa-edit fa-2x"></i></a>
                    <a href="{{route('delete', $event->id)}}" onclick="return confirm('Are you sure you want to delete this?');"><i class="fa fa-trash" style="font-size:36px; color:red"></i></button></a>
                  </div>
            </div>
                @endforeach
</div>
</div>
@endsection

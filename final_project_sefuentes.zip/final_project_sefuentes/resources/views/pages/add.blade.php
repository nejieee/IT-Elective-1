@extends('layout.master')
@section('title')
  Add Event
@endsection
@section('content')

<div class="container pt-4">
  <div class="col-md-8 offset-md-2">

      <form action="{{route('insert')}}" method="post">
        @csrf
        @method('post')

        <div class = "container">
          <div class = "row">
            <div class="form-group">
              <div class="col-md-6 form">
              <center>  <h4> Add Event </h4> </center>

            <label class="form-label"> New task</label>
            <input type="text" class="form-control" name="event_name"required placeholder="Enter Event here">
            <label class="form-label"> Schedule</label>
            <input type="date" class="form-control" name="date">
            <label class="form-label"> Venue </label>
            <input type="text" class="form-control" name="venue"required placeholder="Enter Venue here">
            <label class="form-label"> In charge </label>
            <input type="text" class="form-control" name="incharge"required placeholder="Enter In charge's name here">
            <center><input type="submit" value="Add" class="mt-2 btn btn-success">
            <a href="{{route('front-page')}}" class="mt-2 btn btn-danger"> Cancel </a> </center>
          </div>
      </div>
      </div>
    </div>
      </form>
    </div>
  </div>

@endsection

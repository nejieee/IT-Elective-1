<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Event;

class EventController extends Controller
{
    public function show(){
      $events = Event::all();

      return view("pages.home")->with("events",$events);
    }

    public function insert(Request $request){

      $this->validate($request, [
        'event_name' => 'required',
        'date' => 'required',
        'venue' => 'required' ,
        'incharge' => 'required'
      ]);
      $event = new Event();

      $event->event_name = $request->event_name;
      $event->date = $request->date;
      $event->venue = $request->venue;
      $event->incharge = $request->incharge;
      $event->save();
      return redirect()->route('front-page');


    }
    public function edit($id){

      $event = Event::find($id);
      return view("pages.edit")->with("event",$event);
    }

    public function update(Request $request, $id){
      $event = Event::find($id);

      $event->event_name = $request->event_name;
      $event->date = $request->date;
      $event->venue = $request->venue;
      $event->incharge = $request->incharge;

      $event->save();
      return redirect()->route('front-page');
    }
    public function delete($id){
    $event = Event::find($id);

    Event::destroy($id);
    return redirect()->route('front-page');
    }
    public function view($id)
    {
      $event = Event::find($id);
      return view("pages.event")->with("event" , $event);
    }

}

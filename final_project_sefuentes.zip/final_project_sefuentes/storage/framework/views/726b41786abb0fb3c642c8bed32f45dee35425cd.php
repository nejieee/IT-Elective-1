
<?php $__env->startSection('title'); ?>
  Specific Event
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

  <div>
  <div class="col-md-3 offset-md-4 pt-5">
    <div class="form ">
      <span><h5> Event Details </h5></</span><br>

<center>
      <span><span><h3><?php echo e($event->event_name); ?></span></span></h3>
      <div class="pt-4">
      <h5> Schedule: <?php echo e($event->date); ?> </h5>
      <h5> Venue: <?php echo e($event->venue); ?> </h5>
      <h5> In Charge: <?php echo e($event->incharge); ?> </h5></i>
    <a href="<?php echo e(route('front-page')); ?>"> <i class="	fa fa-arrow-circle-left" style="font-size:48px; color:red"></i> </a></center><br>

    </div>
  </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel App\final_project\resources\views/pages/event.blade.php ENDPATH**/ ?>
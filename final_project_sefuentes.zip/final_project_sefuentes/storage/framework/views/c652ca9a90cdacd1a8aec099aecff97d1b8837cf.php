
<?php $__env->startSection('title'); ?>
  Add Event
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container pt-4">
  <div class="col-md-8 offset-md-2">

      <form action="<?php echo e(route('insert')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>

        <div class = "container">
          <div class = "row">
            <div class="form-group">
              <div class="col-md-6 form">
              <center>  <h4> Add Event </h4> </center>

            <label class="form-label"> New task</label>
            <input type="text" class="form-control" name="event_name"required placeholder="Enter Event here">
            <label class="form-label"> Schedule</label>
            <input type="date" class="form-control" name="date">
            <label class="form-label"> Venue </label>
            <input type="text" class="form-control" name="venue"required placeholder="Enter Venue here">
            <label class="form-label"> In charge </label>
            <input type="text" class="form-control" name="incharge"required placeholder="Enter In charge's name here">
            <center><input type="submit" value="Add" class="mt-2 btn btn-success">
            <a href="<?php echo e(route('front-page')); ?>" class="mt-2 btn btn-danger"> Cancel </a> </center>
          </div>
      </div>
      </div>
    </div>
      </form>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel App\final_project\resources\views/pages/add.blade.php ENDPATH**/ ?>
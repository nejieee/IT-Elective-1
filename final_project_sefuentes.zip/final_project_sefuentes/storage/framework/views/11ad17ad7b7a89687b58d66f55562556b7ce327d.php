
<?php $__env->startSection('title'); ?>
  Event Management System
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class = "container border border-dark mt-3 pt-3"> <br>
  <h2> <center> Event Management System </center></h2> <br>
      <div class="add">
      <a href="<?php echo e(route('add')); ?>"> <i class="fa fa-plus-circle fa-3x" aria-hidden="true" ></i> </a><br> 
    </div>
<div class="row-grid">

      <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
              <div class = "container"> <br>
                <h4><?php echo e($event->event_name); ?> </h4>
                    <a href="<?php echo e(route('view', $event->id)); ?>"><i class="fa fa-eye" style="font-size:36px; color:black"></i></a>
                    <a href="<?php echo e(route('edit', $event->id)); ?>"><i class="fa fa-edit fa-2x"></i></a>
                    <a href="<?php echo e(route('delete', $event->id)); ?>" onclick="return confirm('Are you sure you want to delete this?');"><i class="fa fa-trash" style="font-size:36px; color:red"></i></button></a>
                  </div>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel App\final_project\resources\views/pages/home.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title'); ?> </title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">


  </head>
  <body>


    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(asset('js/test.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>





  </body>
</html>
<?php /**PATH C:\Laravel App\app_4\resources\views/layout/master.blade.php ENDPATH**/ ?>
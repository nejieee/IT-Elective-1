<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EventController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [EventController::class, "show"])->name("front-page");

Route::get('add-event', function(){
        return view("pages.add");
})->name('add');

Route::post('insert', [EventController::class, "insert"])->name("insert");
Route::get('edit/{id}', [EventController::class, "edit"])->name("edit");
Route::post('update/{id}', [EventController::class, "update"])->name("update");
Route::get('delete/{id}', [EventController::class, "delete"])->name("delete");
Route::get('view/{id}', [EventController::class, "view"])->name("view");
